# Assignment 4 - Color and Multi-scale Representations

## Authors
- Albert Cerfeda

## Exercises solved
### Color Palette Extraction from Images [7 points]
- #### Linear RGB and sRGB Color Palettes
- #### CIELab Color Palette

### Color Quantization and lookup tables (LUTs) [3 points]
  - **+ Bonus [2 points]**

### Gaussian and Laplacian Pyramids [4 points]
### Hybrid Images [3 points]
### Theory: Hybrid Images [3 points]
### **Bonus: Create your own Instagram Filter! [10 points]**