# Assignment 3 - Frequency Domain Processing

## Authors
- Albert Cerfeda
- Alessandro Gobbetti