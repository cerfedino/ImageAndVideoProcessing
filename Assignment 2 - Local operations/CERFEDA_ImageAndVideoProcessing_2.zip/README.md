# Assignment 2 - Local operations

## Authors
- Albert Cerfeda
